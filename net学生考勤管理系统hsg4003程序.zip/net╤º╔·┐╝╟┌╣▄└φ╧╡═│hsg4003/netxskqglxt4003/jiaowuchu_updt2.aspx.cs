using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class jiaowuchu_updt2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

       
   
        if (!IsPostBack)
        {
			
			xingbie.Items.Add("��"); xingbie.Items.Add("Ů");			
			
			
			yonghuming.ReadOnly = true;
            string sql;
            sql = "select * from jiaowuchu where yonghuming='" + Session["username"].ToString().Trim() + "'";
            getdata(sql);
        }
    }

	

    private void getdata(string sql)
    {
        DataSet result = new DataSet();
        result = new Class1().hsggetdata(sql);
        if (result != null)
        {
            if (result.Tables[0].Rows.Count > 0)
            {
                yonghuming.Text = result.Tables[0].Rows[0]["yonghuming"].ToString().Trim();                mima.Text = result.Tables[0].Rows[0]["mima"].ToString().Trim();                xingming.Text = result.Tables[0].Rows[0]["xingming"].ToString().Trim();                xingbie.Text = result.Tables[0].Rows[0]["xingbie"].ToString().Trim();                shouji.Text = result.Tables[0].Rows[0]["shouji"].ToString().Trim();                beizhu.Text = result.Tables[0].Rows[0]["beizhu"].ToString().Trim();                
                
            }
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        
        string sql;
        
        sql = "update jiaowuchu set yonghuming='" + yonghuming.Text.ToString().Trim() + "',mima='" + mima.Text.ToString().Trim() + "',xingming='" + xingming.Text.ToString().Trim() + "',xingbie='" + xingbie.Text.ToString().Trim() + "',shouji='" + shouji.Text.ToString().Trim() + "',beizhu='" + beizhu.Text.ToString().Trim() + "' where yonghuming='" + Session["username"].ToString().Trim() + "'";
        int result;
        result = new Class1().hsgexucute(sql);
        if (result == 1)
        {
            Response.Write("<script>javascript:alert('�޸ĳɹ�');</script>");
        }
        else
        {
            Response.Write("<script>javascript:alert('ϵͳ����');</script>");
        }
    }
	
	
   
    
   
    
}

