using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class renkelaoshi_add : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
		if (!IsPostBack)
        {
			
			xingbie.Items.Add("��"); xingbie.Items.Add("Ů");			
			
            
			
			addxiala("banjixinxi","banji","banji");			 
			
			
			
           
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
		
        string sql;
		
		
		ischongfu("select id from renkelaoshi where  yonghuming='"+yonghuming.Text.ToString().Trim()+"'");
		
		
        sql="insert into renkelaoshi(yonghuming,mima,xingming,xingbie,banji,shouji,beizhu) values('"+yonghuming.Text.ToString().Trim()+"','"+mima.Text.ToString().Trim()+"','"+xingming.Text.ToString().Trim()+"','"+xingbie.Text.ToString().Trim()+"','"+banji.Text.ToString().Trim()+"','"+shouji.Text.ToString().Trim()+"','"+beizhu.Text.ToString().Trim()+"') ";
        int result;
        result = new Class1().hsgexucute(sql);
        if (result == 1)
        {
            Response.Write("<script>javascript:alert('���ӳɹ�');</script>");
        }
        else
        {
            Response.Write("<script>javascript:alert('ϵͳ�����������ݿ���������');</script>");
        }
    }
	
	
	private void addxiala(string ntable, string nzd,string nkjm)
    {
     
        string sql;
        sql = "select " + nzd + " from " + ntable + " order by id desc";
        DataSet result = new DataSet();
        result = new Class1().hsggetdata(sql);
        if (result != null)
        {
            if (result.Tables[0].Rows.Count > 0)
            {
                int i = 0;
                for (i = 0; i < result.Tables[0].Rows.Count; i++)
                {
                    ((DropDownList)this.FindControl(nkjm)).Items.Add(result.Tables[0].Rows[i][0].ToString().Trim());
                 
                }
            }
        }
    }
	
	public void ischongfu(string sql)
    {
        DataSet result = new DataSet();
            result = new Class1().hsggetdata(sql);
            if (result != null)
            {
                if (result.Tables[0].Rows.Count > 0)
                {
                    Response.Write("<script>javascript:alert('��ʾ,�û����Ѵ���,��Ҫ�ظ�����');location.href='renkelaoshi_add.aspx';</script>");
                    Response.End();
                }
            }
    }
	
	
	
	
	
	
	
}

