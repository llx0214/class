using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class kaoqinxinxi_add : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
		if (!IsPostBack)
        {
			
			
			
            xuehao.Text = Session["username"].ToString().Trim();xuehao.ReadOnly = true;
			
			 
			
			  string sqllb = "select * from xueshengxinxi where id=" + Request.QueryString["id"].ToString().Trim();
			  DataSet resultlb = new DataSet();
			  resultlb = new Class1().hsggetdata(sqllb);
			  if (resultlb != null)
			  {
			    if (resultlb.Tables[0].Rows.Count > 0)
			     {
			        xuehao.Text = resultlb.Tables[0].Rows[0]["xuehao"].ToString().Trim();                    xuehao.ReadOnly = true;                    xingming.Text = resultlb.Tables[0].Rows[0]["xingming"].ToString().Trim();                    xingming.ReadOnly = true;                    xingbie.Text = resultlb.Tables[0].Rows[0]["xingbie"].ToString().Trim();                    xingbie.ReadOnly = true;                    banji.Text = resultlb.Tables[0].Rows[0]["banji"].ToString().Trim();                    banji.ReadOnly = true;                    zhuangtai.Text = resultlb.Tables[0].Rows[0]["zhuangtai"].ToString().Trim();                    zhuangtai.ReadOnly = true;                    
			     }
			  }
			
           
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
		
        string sql;
		
		
		
		
		
        sql="insert into kaoqinxinxi(xuehao,xingming,xingbie,banji,zhuangtai,riqi,beizhu) values('"+xuehao.Text.ToString().Trim()+"','"+xingming.Text.ToString().Trim()+"','"+xingbie.Text.ToString().Trim()+"','"+banji.Text.ToString().Trim()+"','"+zhuangtai.Text.ToString().Trim()+"','"+riqi.Text.ToString().Trim()+"','"+beizhu.Text.ToString().Trim()+"') ";
        int result;
        result = new Class1().hsgexucute(sql);
        if (result == 1)
        {
            Response.Write("<script>javascript:alert('���ӳɹ�');</script>");
        }
        else
        {
            Response.Write("<script>javascript:alert('ϵͳ�����������ݿ���������');</script>");
        }
    }
	
	
	
	
	
	
	
	
	
	
	
}

