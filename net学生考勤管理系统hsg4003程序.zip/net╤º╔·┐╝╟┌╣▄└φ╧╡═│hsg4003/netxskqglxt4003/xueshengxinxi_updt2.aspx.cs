using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class xueshengxinxi_updt2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

       
   
        if (!IsPostBack)
        {
			
			xingbie.Items.Add("��"); xingbie.Items.Add("Ů");
			zhuangtai.Items.Add("��У"); zhuangtai.Items.Add("���"); 
			
			
			addxiala("banjixinxi","banji","banji");
			
			xuehao.ReadOnly = true;
            string sql;
            sql = "select * from xueshengxinxi where xuehao='" + Session["username"].ToString().Trim() + "'";
            getdata(sql);
        }
    }

	

    private void getdata(string sql)
    {
        DataSet result = new DataSet();
        result = new Class1().hsggetdata(sql);
        if (result != null)
        {
            if (result.Tables[0].Rows.Count > 0)
            {
                xuehao.Text = result.Tables[0].Rows[0]["xuehao"].ToString().Trim();
                mima.Text = result.Tables[0].Rows[0]["mima"].ToString().Trim();
                xingming.Text = result.Tables[0].Rows[0]["xingming"].ToString().Trim();
                xingbie.Text = result.Tables[0].Rows[0]["xingbie"].ToString().Trim();
                banji.Text = result.Tables[0].Rows[0]["banji"].ToString().Trim();
                zhuangtai.Text = result.Tables[0].Rows[0]["zhuangtai"].ToString().Trim();
                shouji.Text = result.Tables[0].Rows[0]["shouji"].ToString().Trim();
                beizhu.Text = result.Tables[0].Rows[0]["beizhu"].ToString().Trim();
                
                
            }
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        
        string sql;
        
        sql = "update xueshengxinxi set xuehao='" + xuehao.Text.ToString().Trim() + "',mima='" + mima.Text.ToString().Trim() + "',xingming='" + xingming.Text.ToString().Trim() + "',xingbie='" + xingbie.Text.ToString().Trim() + "',banji='" + banji.Text.ToString().Trim() + "',zhuangtai='" + zhuangtai.Text.ToString().Trim() + "',shouji='" + shouji.Text.ToString().Trim() + "',beizhu='" + beizhu.Text.ToString().Trim() + "' where xuehao='" + Session["username"].ToString().Trim() + "'";
        int result;
        result = new Class1().hsgexucute(sql);
        if (result == 1)
        {
            Response.Write("<script>javascript:alert('�޸ĳɹ�');</script>");
        }
        else
        {
            Response.Write("<script>javascript:alert('ϵͳ����');</script>");
        }
    }
	
	
	private void addxiala(string ntable, string nzd,string nkjm)
    {
     
        string sql;
        sql = "select " + nzd + " from " + ntable + " order by id desc";
        DataSet result = new DataSet();
        result = new Class1().hsggetdata(sql);
        if (result != null)
        {
            if (result.Tables[0].Rows.Count > 0)
            {
                int i = 0;
                for (i = 0; i < result.Tables[0].Rows.Count; i++)
                {
                    ((DropDownList)this.FindControl(nkjm)).Items.Add(result.Tables[0].Rows[i][0].ToString().Trim());
                 
                }
            }
        }
    }
   
    
   
    
}

